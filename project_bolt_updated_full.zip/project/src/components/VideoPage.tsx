
import React, { useEffect, useState } from 'react';
import { Link, useParams, useLocation } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { VideoData } from '../lib/supabase-types';
import { supabase } from '../lib/supabase';

const VideoPage: React.FC = () => {
  const { category, id } = useParams<{ category: string; id: string }>();
  const location = useLocation();
  const [video, setVideo] = useState<VideoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchVideo = async () => {
      if (!id) return;

      try {
        // Check if the session is valid
        const session = supabase.auth.session();
        if (!session) {
          setError('Session has expired. Please log in again.');
          window.location.href = '/login';
          return;
        }

        // Fetch video data
        const { data, error } = await supabase
          .from('videos')
          .select('*')
          .eq('id', id)
          .single();

        if (error) throw error;
        setVideo(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load video');
        if (err?.status === 401) {
          window.location.href = '/login'; // Redirect to login on unauthorized access
        }
      } finally {
        setLoading(false);
      }
    };

    fetchVideo();
  }, [id]);

  useEffect(() => {
    // Subscribe to real-time updates for the videos table
    const subscription = supabase
      .from('videos')
      .on('INSERT', payload => {
        console.log('New video added:', payload.new);
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // Get the search params from the state passed through navigation
  const searchParams = location.state?.searchParams || '';

  // Create back link URL with preserved filters
  const backToGalleryUrl = `/${category}${searchParams}`;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen text-red-500">
        <p>{error}</p>
        <Link to="/login" className="mt-4 text-blue-500 underline">
          Go to Login
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <Link to={backToGalleryUrl} className="flex items-center mb-4 text-blue-500">
        <ArrowLeft className="mr-2" /> Back to Gallery
      </Link>
      {video && (
        <div>
          <h1 className="text-2xl font-bold mb-4">{video.title}</h1>
          <video controls className="w-full">
            <source src={video.url} type="video/mp4" />
          </video>
          <p className="mt-4">{video.description}</p>
        </div>
      )}
    </div>
  );
};

export default VideoPage;
