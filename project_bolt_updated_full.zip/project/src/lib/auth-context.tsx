
                            const session = supabase.auth.session();
                            if (!session) {
                                console.error('Session expired. Redirecting to login.');
                                window.location.href = '/login';
                                return;
                            }
                            
import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from './supabase';
import { Profile } from './supabase-types';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  session: Session | null;
  loading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signUp: (email: string, password: string, username: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<{ success: boolean; error?: string }>;
  updateProfile: (updates: Partial<Profile>) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    let mounted = true;

    async function initialize() {
      try {
        // Get initial session
        const { data: { session: initialSession } } = await supabase.auth.getSession();
        
        if (initialSession) {
          setSession(initialSession);
          setUser(initialSession.user);
          setIsAuthenticated(true);
        } else {
          setIsAuthenticated(false);
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    initialize();

    return () => {
      mounted = false;
    };
  }, []);

  // Add session state listener
  useEffect(() => {
    const { data: subscription } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user || null);
      setIsAuthenticated(!!session?.user);
    });

    return () => subscription?.unsubscribe();
  }, []);

  // Add session refresh timer
  useEffect(() => {
    const refreshToken = async () => {
      const { error } = await supabase.auth.refreshSession();
      if (error) {
        console.error('Session refresh error:', error.message);
        setError(error.message);
      }
    };

    const interval = setInterval(refreshToken, 1000 * 60 * 15); // Refresh every 15 minutes
    return () => clearInterval(interval);
  }, []);

  // Redirect if unauthenticated
  useEffect(() => {
    if (!isAuthenticated && !loading) {
      window.location.href = '/login';
    }
  }, [isAuthenticated, loading]);

  const value = {
    user,
    profile,
    session,
    loading,
    error,
    isAuthenticated,
    signIn: async (email: string, password: string) => {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        setError(error.message);
        return { success: false, error: error.message };
      }
      return { success: true };
    },
    signUp: async (email: string, password: string, username: string) => {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { username } },
      });
      if (error) {
        setError(error.message);
        return { success: false, error: error.message };
      }
      return { success: true };
    },
    signOut: async () => {
      const { error } = await supabase.auth.signOut();
      if (error) {
        setError(error.message);
        return { success: false, error: error.message };
      }
      setUser(null);
      setProfile(null);
      setSession(null);
      setIsAuthenticated(false);
      return { success: true };
    },
    updateProfile: async (updates: Partial<Profile>) => {
      const { error } = await supabase.from('profiles').update(updates).eq('id', user?.id);
      if (error) {
        setError(error.message);
        return { success: false, error: error.message };
      }
      return { success: true };
    },
  };

  return <AuthContext.Provider value={value}>{!loading && children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
